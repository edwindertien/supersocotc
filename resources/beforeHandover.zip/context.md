# Super Soco TC — FarDriver Conversion: Handoff Context

This document is a complete handoff for a fresh conversation continuing this project.

---

## Project summary

2021 Super Soco TC electric motorcycle. Replacing the stock motor controller with a **FarDriver ND72360** to enable regenerative braking. The original stock controller already had regen (detected via RS485 bus capture), but was causing thermal shutdowns at max speed.

**First problem solved along the way:** Bosch hub motor Hall sensor (yellow channel, 100Ω short to GND) → E96 error. Fixed by repair and correct angular reassembly. Battery terminal corrosion also caused a no-start.

---

## Hardware

| Item | Detail |
|---|---|
| Bike | 2021 Super Soco TC |
| Motor | Bosch hub motor, 1500W BLDC, 12", 3× Hall + thermistor (white wire) |
| Battery | 17S NMC, nominal 61.2V, full charge 71.4V, cutoff ~52V |
| New controller | FarDriver ND72360, model JSNJ012404, HW ver H/8, SW ver 8.5 |
| Dev machine | MacBook Pro (username Dertien), Python 3.11 via PlatformIO venv |
| Serial adapter | USB-TTL 3.3V (CP2102 or similar), port `/dev/tty.usbserial-AD026699` |

### FarDriver serial header (4-pin, labelled "USB")
```
Pin 1  3.3V  ← DO NOT CONNECT
Pin 2  GND   → adapter GND
Pin 3  RXD   → adapter TX
Pin 4  TXD   → adapter RX
Baud: 19200, 8N1
```

---

## RS485 bus architecture (confirmed by bus capture)

**Three units on the bus. Instrument panel is bus master — no ECU.**

| Address | Unit | Role |
|---|---|---|
| 0xBA | Instrument panel | ★ Bus master — polls controller + battery |
| 0xDA | Stock controller | Slave — reports speed/gear/current/temp |
| 0x5A | Battery | Slave — reports voltage/SoC/temp/cycles |

ECU socket (0xAA) is physically present on the wiring harness but **unpopulated**. There is a secondary RS485 segment for an optional second battery (same addresses).

Protocol: 9600 baud, 8N1, request `0xC5 0x5C`, response `0xB6 0x6B`, XOR checksum.

Speed factor: `0.109` (empirically calibrated — C# source says 0.028, that's wrong).

Regen confirmed on stock TC: activates at ~28 km/h on throttle roll-off, battery reports `Activity=charging`.

**Resources:**
- https://github.com/stprograms/SuperSoco485Monitor
- https://github.com/stprograms/SuperSoco485

---

## FarDriver serial protocol

**Resources:**
- https://github.com/jackhumbert/fardriver-controllers ← primary reference, C++ structs + README
- https://github.com/bobecek79/ESP32-Fardriver-BLE-Reader

### BT handshake (MUST be emulated before data flows)

The "USB" header is shared with the BT module. Without the physical BT dongle, the controller loops on `AT+VERSION`. The handshake must be emulated:

```
FarDriver → us:  AT+VERSION  (10 bytes, no terminator)
us → FarDriver:  +VERSION=\x01\x08k\x199\xa4\xe2~\x86\x97\xd8\xe6{\xfd\xb1g\r\n  (27 bytes)
FarDriver → us:  AT+PAWD=<16 bytes>  (24 bytes)
us → FarDriver:  +PAWD=\xce\x1d\r\x8d9\x9f\xd3\xf3\x86\x91\xf6B|w\x85\xe1  (22 bytes, NO \r\n)
× 3 rounds of PAWD, then data frames begin at ~50fps
```

Captured via Saleae logic analyser (files: `startupRX.txt`, `startupTX.txt`).

### Read frames (controller → us, 16 bytes each)

```
AA [0x80|id] [data 12 bytes] [crc_a] [crc_b]
```

CRC: two-table algorithm, init `a=0x3C, b=0x7F`. The `flashReadAddr` table maps id → block address:
```
[0xE2,0xE8,0xEE,0x00,0x06,0x0C,0x12,0xE2,0xE8,0xEE,0x18,0x1E,0x24,0x2A,
 0xE2,0xE8,0xEE,0x30,0x5D,0x63,0x69,0xE2,0xE8,0xEE,0x7C,0x82,0x88,0x8E,
 0xE2,0xE8,0xEE,0x94,0x9A,0xA0,0xA6,0xE2,0xE8,0xEE,0xAC,0xB2,0xB8,0xBE,
 0xE2,0xE8,0xEE,0xC4,0xCA,0xD0,0xE2,0xE8,0xEE,0xD6,0xDC,0xF4,0xFA]
```

Key addresses decoded from live stream (controller values at time of last session):
| Block addr | Key fields | Confirmed values |
|---|---|---|
| 0xE2 | gear, forward/reverse, speed_raw, modulation, fault flags | gear=1, forward=true |
| 0xE8 | voltage (/10), line_current (/4) | 65.0V, 0.0A |
| 0xCA | angle_learn | **0xAA = LEARNED** (self-learn complete) |
| 0x12 | LD(word0x12), AlarmDelay(0x13), PolePairs(0x14), MaxSpeed(0x15), RatedPower(0x16), RatedVoltage(0x17/10) | poles=4, power=3000W, voltage=72V |
| 0x18 | RatedSpeed(0x18), MaxLineCurr(0x19,×4) | 4500RPM, 190A |
| 0x1E | FwReRatio(0x1E), flags(pad), **LowVolProtect(0x1F,/10)** | **63.0V ← needs changing to 54V** |
| 0x30 | StopBackCurr(0x30), MaxBackCurr(0x31) | 2A, 4A ← increase for regen |
| 0x82 | motor_temp_protect(byte4), restore(byte5), mos_protect(byte6), hw_ver(byte10), sw_ver(byte11) | 160°C, 140°C, 100°C, HW=8, SW=8.5 |
| 0xA0 | model name bytes 2-10 | "JSNJ012404" |

### Write format (from README + fardriver.hpp static_assert)

```
AA C6 [word_addr] [word_addr] [lo] [hi] [crc_a] [crc_b]
```

- `0xC6` = flags=1 (write), compute_length=6
- Both bytes 2-3 are the **same** word address (addr_confirm)
- **WORD addressing confirmed** by `static_assert: offsetof(FardriverData, addr12) == (0x12 << 1)`
- `GetAddr(addr)` = `(uint8_t*)this + (addr << 1)` → each addr unit = 2 bytes
- Word address = block_base + (byte_offset_within_block / 2)

### Confirmed write addresses (PARAM_MAP, word addressing)

| Parameter | Word addr | Scale | Notes |
|---|---|---|---|
| low_vol_protect | **0x1F** | ×10 | Addr1E byte2 → word 1 → 0x1E+1 |
| rated_speed | 0x18 | 1 RPM | Addr18 word 0 |
| max_line_curr | 0x19 | ×4 A | Addr18 word 1 |
| stop_back_curr | 0x30 | 1 A | Addr30 word 0 |
| max_back_curr | 0x31 | 1 A | Addr30 word 1 |
| back_speed | 0x28 | 1 RPM | Addr24 word 4 |
| low_speed | 0x29 | 1 RPM | Addr24 word 5 |
| max_phase_curr | 0x2D | ×4 A | Addr2A word 3 |
| temp_sensor | 0x0B | 1 | Addr06, bits 4-6 of byte 12 |

**DO NOT write to word 0x12** — that is `LD` (Weak Magnetic Function Coefficient), not TempSensor. Writing 0x0006 there caused erratic controller behaviour.

### System commands (write to addr 0xA0 with prefix 0x88)

| Command | Packet | Effect |
|---|---|---|
| Self-learn | `AA C6 A0 A0 88 02 45 0E` | Start Hall angle detection |
| Data gather | `AA C6 A0 A0 88 06 44 CD` | Start streaming |
| Reset | `AA C6 A0 A0 88 05 04 CC` | Soft reset (resets, may save first) |
| Factory restore | `AA C6 A0 A0 88 08 C5 09` | Restore flash defaults to RAM |

---

## Current status of write/save mechanism — UNRESOLVED

This is the main open problem.

**What is confirmed:**
- Write packet `AA C6 1F 1F 1C 02 3F FE` (LowVolProtect=54V) **works in RAM** — the controller immediately echoes back 54.0V in the next 0x1E streaming block ✓
- After power cycle or `0x05` reset, value reverts to 63.0V ✗

**What has been tried:**
1. Write + `0x05` reset → reverts (0x05 resets but apparently doesn't save)
2. Write + SaveNum increment (word 0x0A) → no reset, but still reverts on power cycle
3. Write only, no follow-up → reverts on power cycle
4. Write + `0x05` with 300ms delay → still reverts

**Hypotheses to test next:**
- `WriteAddr` may genuinely write to flash directly (README says so), but `0x05` reset happens too fast and corrupts the flash write. Test: write, wait 2+ seconds, then power cycle manually — does it persist?
- The old-style command format `0x05` (different from syscmd): `AA 05 FA 01 5F 5F 68 97` — this is what ConnectPage.cs sends after date/time writes, may be the actual flash commit
- `0x04` syscmd ("gets CAN parameters?") — unknown, may be related to save
- Capturing what the real FarDriver app sends via Saleae when you change and save a parameter would definitively resolve this

**Settings that need changing before riding:**
| Parameter | Current | Target | Write packet |
|---|---|---|---|
| LowVolProtect | 63V | **54V** | `AA C6 1F 1F 1C 02 3F FE` |
| StopBackCurr | 2A | **10A** | `AA C6 30 30 0A 00 89 42` |
| MaxBackCurr | 4A | **20A** | `AA C6 31 31 14 00 D0 DE` |
| TempSensor | ? | **NTC-10K (6)** | `AA C6 0B 0B 06 00 ...` |

**Throttle:** self-learn already completed (angle_learn=0xAA), but throttle thresholds are wrong (6.4V/0V). Physical self-learn re-run needed with rear wheel off ground.

---

## Tool files (in `/mnt/user-data/outputs/` and Edwin's `~/git/supersocotc/`)

| File | Description |
|---|---|
| `fardriver_web.py` | Flask web tool for FarDriver: dashboard, pre-flight checks, settings display, write parameters, commands (self-learn etc.), log. Run: `python3 fardriver_web.py --port /dev/tty.usbserial-AD026699` |
| `supersoco_web.py` | Flask web tool for Super Soco RS485 bus monitor. Run: `python3 supersoco_web.py --port /dev/...` |
| `supersoco_monitor.py` | Terminal RS485 monitor |
| `docs/architecture_original.svg` | Assumed 4-unit bus architecture (incorrect) |
| `docs/architecture_actual.svg` | Actual architecture: panel as master, no ECU |
| `docs/architecture_target.svg` | Target: FarDriver + Pico W RS485 bridge |
| `docs/hall_sensor_fault.svg` | Hall sensor diagnosis diagram |
| `README.md` | Full project summary |

### fardriver_web.py key implementation details

- BT handshake fully emulated (VERSION + 3× PAWD using captured Saleae bytes)
- `PARAM_MAP` uses word addresses (confirmed via static_assert analysis)
- `write_param(word_addr, raw_u16)` → `AA C6 addr addr lo hi crc crc`
- Write CONFIRMS by reading back from streaming data (4s delay to allow reset+reboot)
- Pre-flight tab: 10 health checks including Hall, phase, throttle, brake, temp, auto-learn
- Edit tab: inline editors for key parameters with live current-value display
- Log tab: full raw RX hex, filterable, downloadable
- `do_save=True` default: sends `0x05` after write — currently NOT persisting values

---

## Next steps

**Immediate (write persistence):**
1. Test: write `0x1F` with save=False, wait 3 seconds (no reset), then manually power cycle — check if 54V persists on reconnect
2. If not: try old-style 0x05 command: `AA 05 FA 01 5F 5F 68 97`
3. If not: capture a real write from FarDriver app using Saleae (connect phone, change one param, capture TX)

**Once write works:**
1. Set LowVolProtect = 54V (currently 63V — causing 5-beep undervoltage warning)
2. Set TempSensor = 6 (NTC-10K) — currently causing temp protection issues
3. Increase StopBackCurr (2A→10A) and MaxBackCurr (4A→20A) for meaningful regen
4. Run throttle self-learn with rear wheel off ground

**Longer term:**
- Raspberry Pi Pico W RS485 bridge firmware: reads FarDriver serial + polls battery + emits SpeedometerRequest to stock display
- Ignition switch wiring (replace remote/key with barrel switch → KEY pin)
- Optional circular touchscreen for temperature + regen display

---

## Key resources

| Resource | URL |
|---|---|
| jackhumbert fardriver-controllers | https://github.com/jackhumbert/fardriver-controllers |
| SuperSoco485Monitor | https://github.com/stprograms/SuperSoco485Monitor |
| SuperSoco485 Arduino lib | https://github.com/stprograms/SuperSoco485 |
| ESP32 FarDriver BLE reader | https://github.com/bobecek79/ESP32-Fardriver-BLE-Reader |
| Endless Sphere FarDriver thread | https://endless-sphere.com/sphere/threads/fardriver-controller-serial-protocol-reverse-engineering.121825/ |